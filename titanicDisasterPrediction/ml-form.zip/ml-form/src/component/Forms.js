import React, { useState } from 'react'

export default function Forms(){
  const [embarked, SetEmbarked] = useState('')
  const [age, SetAge] = useState('')
  const [sex, SetSex] = useState('')
  const [parch, SetPArch] = useState('')
  const [faire, SetFaire] = useState('')
  const [sibsp, SetSibsp] = useState('')
  const [pclass, SetPclass] = useState('')
  const [res,SetRes] = useState('')
  const [v,SetV] = useState('')
  const handlEmbarkedChange = (e)=>{
    SetEmbarked(e.target.value);
  }

  const handleAgeChange = (e) =>{
    SetAge(e.target.value);
  }

  const handleSexChange = (e)=>{
    SetSex(e.target.value)
  }

  const handlePArchChange = (e)=>{
    SetPArch(e.target.value)
  }

  const handleFaireChange = (e)=>{
    SetFaire(e.target.value)
  }

  const handleSibsp = (e)=>{
    SetSibsp(e.target.value)
  }

  const handlePclass = (e)=>{
    SetPclass(e.target.value)
  }
  function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
 }

  async function handleSubmit(e){
    e.preventDefault()
    SetV('unhide')
    var myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/json");

    var raw = JSON.stringify({
      "Sex": sex,
      "SibSp": parseInt(sibsp),
      "Parch": parseInt(parch),
      "Fare": parseInt(faire),
      "Embarked": embarked.toUpperCase(),
      "Pclass": parseInt(pclass),
      "Age": parseInt(age)
    });

    var requestOptions = {
      method: 'POST',
      headers: myHeaders,
      body: raw,
      redirect: 'follow'
    };
    await sleep(3000)
    fetch("http://127.0.0.1:5000/", requestOptions)
      .then(response => response.text())
      .then(result => SetRes(result))
      .catch(error => console.log('error', error));
    if (res===0)
      alert("Survived")
    else
      alert("Dead")
    SetV('hide')
  }

return(
  <>
  <div className='p-5 cs1'>
  <form onSubmit={(e)=>{handleSubmit(e)}}> 
  <div className='row'>
    <h1 className='mb-5'>Titanic Disaster Prediction</h1>
  <div className="col-md-4 ">    
    <label htmlFor="exampleInputEmail1">Embarked</label>
    <input type="text" className="form-control border-removed-input" id="exampleInputEmail1" onChange={(e)=>{handlEmbarkedChange(e)}} placeholder="s/c/q" />
  </div>
  <div className="col-md-4 ">
    <label htmlFor="exampleInputPassword1">Sex</label>
    <input type="text" className="form-control border-removed-input" id="exampleInputPassword1" onChange={(e)=>{handleSexChange(e)}} placeholder="male/female" />
  </div>
  <div className="col-md-4 ">
    <label htmlFor="exampleInputPassword1">Age</label>
    <input type="number" className="form-control border-removed-input" id="exampleInputPassword1" onChange={(e)=>{handleAgeChange(e)}} placeholder="age" />
  </div>
  <div className="col-md-4 ">
    <label htmlFor="exampleInputPassword1">PArch</label>
    <input type="number" className="form-control border-removed-input" id="exampleInputPassword1" onChange={(e)=>{handlePArchChange(e)}} placeholder="0/1" />
  </div>
  <div className="col-md-4 ">
    <label htmlFor="exampleInputPassword1">Faire</label>
    <input type="number" className="form-control border-removed-input" id="exampleInputPassword1" onChange={(e)=>{handleFaireChange(e)}} placeholder="Faire Price" />
  </div>
  <div className="col-md-4 ">
    <label htmlFor="exampleInputPassword1">SibSp</label>
    <input type="number" className="form-control border-removed-input" id="exampleInputPassword1" onChange={(e)=>{handleSibsp(e)}} placeholder="0/1" />
  </div>
  <div className="col-md-4 ">
    <label htmlFor="exampleInputPassword1">Pclass</label>
    <input type="number" className="form-control border-removed-input" id="exampleInputPassword1" onChange={(e)=>{handlePclass(e)}} placeholder="0/1" />
  </div>
  </div>
  <input type="submit" className="btn btn-primary col-md-1" value="Submit" />
  </form>
  <div className='prediction' style={{ visibility: v=== 'unhide'? 'visible': 'hidden'}}>
    <i>predicting...</i>
  </div>
  </div>
</>
)
}
