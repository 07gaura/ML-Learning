import logo from './logo.svg';
import './App.css';
import Forms from './component/Forms'
function App() {
  return (
    <>
    <div className='container '>
      <Forms />
    </div>     
    </>
  );
}

export default App;
